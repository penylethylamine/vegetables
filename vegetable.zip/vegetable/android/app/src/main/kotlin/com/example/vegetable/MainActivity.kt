package com.example.vegetable

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
