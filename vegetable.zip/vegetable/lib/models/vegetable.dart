class Vegetable {
  int? id;
  String? name;
  String? price;
  bool? isFavorite;
  String? imagePath;
  String? tip;
  String? desc;

  Vegetable({
    this.id,
    this.name,
    this.price,
    this.isFavorite,
    this.imagePath,
    this.tip,
    this.desc,
  });

  factory Vegetable.fromJson(Map<String, dynamic> json) => Vegetable(
        id: json['id'] as int?,
        name: json['name'] as String?,
        price: json['price'] as String?,
        isFavorite: json['isFavorite'] as bool?,
        imagePath: json['imagePath'] as String?,
        tip: json['tip'] as String?,
        desc: json['desc'] as String?,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'price': price,
        'isFavorite': isFavorite,
        'imagePath': imagePath,
        'tip': tip,
        'desc': desc,
      };

  static List<Vegetable> vegetableList = <Vegetable>[
    Vegetable(
      id: 0,
      name: "Kentang",
      price: "Rp.14.000/kg",
      imagePath: 'assets/images/cabbage.png',
      isFavorite: true,
      tip: "Cocok untuk menurunkan berat badan",
      desc: "Sawi hijufdsadfadsfsafdsdagfdsgdsgdfsgfsdgdzvdrgresggrsvfdsvdsvrdsvsdvrvdxvds",
    ),
    Vegetable(
      id: 1,
      name: "Kubis Hijau",
      price: "Rp.14.000/kg",
      imagePath: 'assets/images/patato.png',
      isFavorite: true,
      tip: "Cocok untuk menurunkan berat badan",
      desc: "Sawi hijufdsadfadsfsafdsdagfdsgdsgdfsgfsdgdzvdrgresggrsvfdsvdsvrdsvsdvrvdxvds",
    ),
  ];

  static List<Vegetable> popularCourseList = <Vegetable>[
    Vegetable(
      id: 0,
      name: "Wortel",
      price: "Rp.14.000/kg",
      imagePath: 'assets/images/pumpkin.png',
      isFavorite: true,
      tip: "Cocok untuk menurunkan berat badan",
      desc: "Sawi hijufdsadfadsfsafdsdagfdsgdsgdfsgfsdgdzvdrgresggrsvfdsvdsvrdsvsdvrvdxvds",
    ),
    Vegetable(
      id: 0,
      name: "Tomat",
      price: "Rp.14.000/kg",
      imagePath: 'assets/images/red_capsicum.png',
      isFavorite: true,
      tip: "Cocok untuk menurunkan berat badan",
      desc: "Sawi hijufdsadfadsfsafdsdagfdsgdsgdfsgfsdgdzvdrgresggrsvfdsvdsvrdsvsdvrvdxvds",
    ),
    Vegetable(
      id: 0,
      name: "Labu Kuning",
      price: "Rp.14.000/kg",
      imagePath: 'assets/images/cauliflower.png',
      isFavorite: true,
      tip: "Cocok untuk menurunkan berat badan",
      desc: "Sawi hijufdsadfadsfsafdsdagfdsgdsgdfsgfsdgdzvdrgresggrsvfdsvdsvrdsvsdvrvdxvds",
    ),
    Vegetable(
      id: 0,
      name: "Sawi Hijau",
      price: "Rp.14.000/kg",
      imagePath: 'assets/images/carrot.png',
      isFavorite: true,
      tip: "Cocok untuk menurunkan berat badan",
      desc: "Sawi hijufdsadfadsfsafdsdagfdsgdsgdfsgfsdgdzvdrgresggrsvfdsvdsvrdsvsdvrvdxvds",
    ),
  ];
}
