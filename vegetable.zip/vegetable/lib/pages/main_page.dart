import 'package:flutter/material.dart';

import 'home_index_screen.dart';
import 'home_list_screen.dart';

class MainPage extends StatefulWidget{
  const MainPage({super.key});
  @override
  _MainPage createState() => _MainPage();
}

class _MainPage extends State<MainPage> {
  int _currentIndex = 0;
  List<Widget> _pageList = [
    HomeIndexScreen(),
    HomeListScreen(),
    Container(),
    Container(),
  ];
  List<BottomNavigationBarItem> _barItem = [
    BottomNavigationBarItem(icon: Icon(Icons.home), label: ""),
    BottomNavigationBarItem(icon: Icon(Icons.list), label: ""),
    BottomNavigationBarItem(icon: Icon(Icons.shopping_cart_checkout), label: ""),
    BottomNavigationBarItem(icon: Icon(Icons.person), label: ""),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: this._pageList[this._currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        onTap: (int index) {
          setState(() {
            this._currentIndex = index;
          });
        },
        currentIndex: this._currentIndex,
        items: _barItem,
        iconSize: 25,
        fixedColor: Colors.green,
        selectedFontSize: 16,
        unselectedFontSize: 12,
        type: BottomNavigationBarType.fixed,

      ),
    );
  }
}
