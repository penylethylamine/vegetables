import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:http/http.dart' as http;
import '/models/vegetable.dart';

class AsyncVegetablesNotifier extends AsyncNotifier<List<Vegetable>> {
  Future<List<Vegetable>> _fetchVegetables() async {
    try {
      final response = await http.get(Uri.http('localhost:3000', '/vegetables'));
      final vegetablesJson = jsonDecode(response.body) as List;
      final vegetables = vegetablesJson
          .map((vegetableJson) => Vegetable.fromJson(vegetableJson as Map<String, dynamic>))
          .toList();
      return vegetables;
    } catch (e) {

    }
    return Future.value(<Vegetable>[]);

  }

  @override
  Future<List<Vegetable>> build() async {
    // Load initial vegetable list from the remote repository
    return _fetchVegetables();
  }

  Future<void> addVegetable(Vegetable vegetable) async {
    // Set the state to loading
    state = const AsyncValue.loading();
    // Add the new vegetable and reload the vegetable list from the remote repository
    state = await AsyncValue.guard(() async {
      await http.post(Uri.http('localhost:3000', '/vegetables'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode(vegetable.toJson()));
      return _fetchVegetables();
    });
  }

  // Let's allow removing vegetables
  Future<void> removeVegetable(String vegetableId) async {
    state = const AsyncValue.loading();
    state = await AsyncValue.guard(() async {
      await http.delete(Uri.http('localhost:3000', '/vegetables/$vegetableId'));
      return _fetchVegetables();
    });
  }

  // Let's mark a vegetable as completed
  Future<void> toggle(String vegetableId) async {
    state = const AsyncValue.loading();
    state = await AsyncValue.guard(() async {
      await http.patch(
        Uri.http('localhost:3000', '/vegetables/$vegetableId'),
        headers: {'Content-Type': 'application/json'},
        body: <String, dynamic>{'isActive': true},
      );
      return _fetchVegetables();
    });
  }
}

final asyncVegetablesProvider =
    AsyncNotifierProvider<AsyncVegetablesNotifier, List<Vegetable>>(() {
  return AsyncVegetablesNotifier();
});
